package com.emailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
