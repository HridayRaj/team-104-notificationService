package com.smsservice.service;


public interface SmsService {
	
	
	void sendSms();
}
