package com.smsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsserviceApplication.class, args);
	}

}
