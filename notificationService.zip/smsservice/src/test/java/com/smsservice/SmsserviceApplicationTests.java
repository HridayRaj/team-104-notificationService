package com.smsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
